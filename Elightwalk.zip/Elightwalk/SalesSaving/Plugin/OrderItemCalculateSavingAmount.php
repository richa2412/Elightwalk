<?php

namespace Elightwalk\SalesSaving\Plugin;

use Magento\Sales\Model\Order\Item;

class OrderItemCalculateSavingAmount
{
    public function aroundSave(Item $subject, callable $proceed)
    {
        $product = $subject->getProduct();
        $savingAmount = 0;

        if ($product->getSpecialPrice() && $product->getSpecialPrice() < $product->getPrice()) {
            $savingAmount = $product->getPrice() - $product->getSpecialPrice();
        }

        $subject->setSavingAmount($savingAmount);
        return $proceed();
    }
}
