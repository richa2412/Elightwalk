<?php

namespace Elightwalk\SalesSaving\Setup;

use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Catalog\Model\Product;
use Magento\Quote\Setup\QuoteSetupFactory;
use Magento\Sales\Setup\SalesSetupFactory;

class InstallData implements InstallDataInterface
{
    private $eavSetupFactory;
    private $quoteSetupFactory;
    private $salesSetupFactory;

    public function __construct(
        EavSetupFactory $eavSetupFactory,
        QuoteSetupFactory $quoteSetupFactory,
        SalesSetupFactory $salesSetupFactory
    ) {
        $this->eavSetupFactory = $eavSetupFactory;
        $this->quoteSetupFactory = $quoteSetupFactory;
        $this->salesSetupFactory = $salesSetupFactory;
    }

    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
        $eavSetup->addAttribute(
            Product::ENTITY,
            'saving_amount',
            [
                'type' => 'decimal',
                'label' => 'Saving Amount',
                'input' => 'price',
                'backend' => 'Magento\Catalog\Model\Product\Attribute\Backend\Price',
                'required' => false,
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
                'visible' => false,
                'user_defined' => false,
                'default' => '0.00',
            ]
        );

        $quoteSetup = $this->quoteSetupFactory->create(['setup' => $setup]);
        $quoteSetup->addAttribute('quote_item', 'saving_amount', ['type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL, 'nullable' => true, 'length' => '12,4']);
        $quoteSetup->addAttribute('quote_address', 'saving_amount', ['type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL, 'nullable' => true, 'length' => '12,4']);

        $salesSetup = $this->salesSetupFactory->create(['setup' => $setup]);
        $salesSetup->addAttribute('order_item', 'saving_amount', ['type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL, 'nullable' => true, 'length' => '12,4']);
        $salesSetup->addAttribute('order', 'saving_amount', ['type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL, 'nullable' => true, 'length' => '12,4']);

        $setup->endSetup();
    }
}
