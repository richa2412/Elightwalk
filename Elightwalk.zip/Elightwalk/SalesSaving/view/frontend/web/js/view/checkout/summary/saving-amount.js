define([
    'Magento_Checkout/js/view/summary/abstract-total',
    'Magento_Checkout/js/model/quote'
], function (Component, quote) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'Elightwalk_SalesSaving/checkout/summary/saving-amount'
        },

        isDisplayed: function () {
            return this.getPureValue() > 0;
        },

        getPureValue: function () {
            var totals = quote.getTotals()();
            if (totals && totals.saving_amount) {
                return parseFloat(totals.saving_amount);
            }
            return 0;
        }
    });
});
